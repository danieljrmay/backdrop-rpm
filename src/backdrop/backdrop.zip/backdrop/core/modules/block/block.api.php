<?php
/**
 * @file
 * API hooks for the Block module.
 */

/**
 * NOTE: The Block module's hooks are now implemented in the Layout module.
 * Please look in layout.api.php to find them.
 * You can read more in the change record: https://docs.backdropcms.org/node/26861
 */
